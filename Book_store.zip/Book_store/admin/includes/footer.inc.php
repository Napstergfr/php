<div id="footer-wrap">
	<p id="legal">&copy; SSK</a>.</p>
	</div>  