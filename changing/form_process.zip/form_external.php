
<form action="form_process.php" method="post">
    <input name="username" type="text" placeholder="Userame">
    <input name="pass" type="password" placeholder="Password">
    <br>
    <input name="submit" type="submit" value="login">
</form>